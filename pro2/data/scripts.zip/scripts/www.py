import requests
import sys
import re

if len(sys.argv) > 2:
  www = requests.get(sys.argv[1]).text
  
  www = re.sub(r'\s+', ' ', re.sub(r'<.*?>', ' ', re.sub(r'\n', ' ', www)))

  with open(sys.argv[2], 'w') as file:
    file.write(www)
